# OO Java

Olá! Este é o projeto de prática do OO com Java da DIO. 

O objetivo do programa é você conseguir:

* cadastrar produtos e  pedidos; 

* excluir produtos e pedidos;

![image](https://github.com/Jeniffersouza/OO_Java/assets/98287941/3a158de2-91a1-42a7-aa44-3f9e245d48d5)

Algumas considerações deve ser informadas:

* _Nenhum tratamento de erro foi feito_: forneça exatametne o que se pede. Não tente informar dados inexperados que a aplicação irá quebrar e encerrar.

<3

